extends Control


func _on_restart_pressed():
	get_tree().paused = false
	get_tree().reload_current_scene()

func _on_quit_pressed():
	get_tree().quit()


func _on_win_zone_body_entered(body: Node2D) -> void:
	pass # Replace with function body.
